/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2012                    */
/* Created on:     5/7/2026 8:17:55 PM                          */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('Authorship') and o.name = 'FK_AUTHORSH_PARTUCIPA_AUTHOR')
alter table Authorship
   drop constraint FK_AUTHORSH_PARTUCIPA_AUTHOR
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('Authorship') and o.name = 'FK_AUTHORSH_RELATES T_LITERARY')
alter table Authorship
   drop constraint "FK_AUTHORSH_RELATES T_LITERARY"
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('Format') and o.name = 'FK_FORMAT_HAS_LITERARY')
alter table Format
   drop constraint FK_FORMAT_HAS_LITERARY
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('"Order"') and o.name = 'FK_ORDER_MAKES_RETAIL P')
alter table "Order"
   drop constraint "FK_ORDER_MAKES_RETAIL P"
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('Orderitem') and o.name = 'FK_ORDERITE_CONTAINS_ORDER')
alter table Orderitem
   drop constraint FK_ORDERITE_CONTAINS_ORDER
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('Orderitem') and o.name = 'FK_ORDERITE_IS REQUES_FORMAT')
alter table Orderitem
   drop constraint "FK_ORDERITE_IS REQUES_FORMAT"
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Author')
            and   type = 'U')
   drop table Author
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('Authorship')
            and   name  = 'Partucipates in_FK'
            and   indid > 0
            and   indid < 255)
   drop index Authorship."Partucipates in_FK"
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('Authorship')
            and   name  = 'relates to_FK'
            and   indid > 0
            and   indid < 255)
   drop index Authorship."relates to_FK"
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Authorship')
            and   type = 'U')
   drop table Authorship
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('Format')
            and   name  = 'has_FK'
            and   indid > 0
            and   indid < 255)
   drop index Format.has_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Format')
            and   type = 'U')
   drop table Format
go

if exists (select 1
            from  sysobjects
           where  id = object_id('"Literary Work"')
            and   type = 'U')
   drop table "Literary Work"
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('"Order"')
            and   name  = 'makes_FK'
            and   indid > 0
            and   indid < 255)
   drop index "Order".makes_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('"Order"')
            and   type = 'U')
   drop table "Order"
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('Orderitem')
            and   name  = 'is requested in_FK'
            and   indid > 0
            and   indid < 255)
   drop index Orderitem."is requested in_FK"
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('Orderitem')
            and   name  = 'contains_FK'
            and   indid > 0
            and   indid < 255)
   drop index Orderitem.contains_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('Orderitem')
            and   type = 'U')
   drop table Orderitem
go

if exists (select 1
            from  sysobjects
           where  id = object_id('"Retail Partner"')
            and   type = 'U')
   drop table "Retail Partner"
go

/*==============================================================*/
/* Table: Author                                                */
/*==============================================================*/
create table Author (
   AuthorID             char(6)              not null,
   AuthorName           varchar(100)         null,
   Biography            varchar(1000)        null,
   constraint PK_AUTHOR primary key nonclustered (AuthorID)
)
go

/*==============================================================*/
/* Table: Authorship                                            */
/*==============================================================*/
create table Authorship (
   Lit_ISBN             char(10)             not null,
   Aut_AuthorID         char(6)              not null,
   AuthorID             char(6)              not null,
   ISBN                 char(10)             not null,
   Royalty_Percentage   float                null,
   constraint PK_AUTHORSHIP primary key (Lit_ISBN, Aut_AuthorID)
)
go

/*==============================================================*/
/* Index: "relates to_FK"                                       */
/*==============================================================*/
create index "relates to_FK" on Authorship (
Lit_ISBN ASC
)
go

/*==============================================================*/
/* Index: "Partucipates in_FK"                                  */
/*==============================================================*/
create index "Partucipates in_FK" on Authorship (
Aut_AuthorID ASC
)
go

/*==============================================================*/
/* Table: Format                                                */
/*==============================================================*/
create table Format (
   FormatID             char(1)              not null,
   ISBN                 char(10)             not null,
   FormatType           varchar(10)          not null,
   Cost                 float                not null,
   RetailPrice          float                not null,
   constraint PK_FORMAT primary key nonclustered (FormatID)
)
go

/*==============================================================*/
/* Index: has_FK                                                */
/*==============================================================*/
create index has_FK on Format (
ISBN ASC
)
go

/*==============================================================*/
/* Table: "Literary Work"                                       */
/*==============================================================*/
create table "Literary Work" (
   ISBN                 char(10)             not null,
   Title                varchar(200)         not null,
   TargetAge            int                  null,
   Genre                varchar(100)         null,
   constraint "PK_LITERARY WORK" primary key nonclustered (ISBN)
)
go

/*==============================================================*/
/* Table: "Order"                                               */
/*==============================================================*/
create table "Order" (
   OrderID              char(6)              not null,
   PartnerID            char(6)              not null,
   OrderDate            datetime             not null,
   constraint PK_ORDER primary key nonclustered (OrderID)
)
go

/*==============================================================*/
/* Index: makes_FK                                              */
/*==============================================================*/
create index makes_FK on "Order" (
PartnerID ASC
)
go

/*==============================================================*/
/* Table: Orderitem                                             */
/*==============================================================*/
create table Orderitem (
   Ord_OrderID          char(6)              not null,
   For_FormatID         char(1)              not null,
   FormatID             char(1)              not null,
   OrderID              char(6)              not null,
   Quantity             int                  null,
   constraint PK_ORDERITEM primary key (Ord_OrderID, For_FormatID)
)
go

/*==============================================================*/
/* Index: contains_FK                                           */
/*==============================================================*/
create index contains_FK on Orderitem (
Ord_OrderID ASC
)
go

/*==============================================================*/
/* Index: "is requested in_FK"                                  */
/*==============================================================*/
create index "is requested in_FK" on Orderitem (
For_FormatID ASC
)
go

/*==============================================================*/
/* Table: "Retail Partner"                                      */
/*==============================================================*/
create table "Retail Partner" (
   PartnerID            char(6)              not null,
   PartnerName          varchar(200)         not null,
   PartnerType          varchar(100)         null,
   constraint "PK_RETAIL PARTNER" primary key nonclustered (PartnerID)
)
go

alter table Authorship
   add constraint FK_AUTHORSH_PARTUCIPA_AUTHOR foreign key (Aut_AuthorID)
      references Author (AuthorID)
go

alter table Authorship
   add constraint "FK_AUTHORSH_RELATES T_LITERARY" foreign key (Lit_ISBN)
      references "Literary Work" (ISBN)
go

alter table Format
   add constraint FK_FORMAT_HAS_LITERARY foreign key (ISBN)
      references "Literary Work" (ISBN)
go

alter table "Order"
   add constraint "FK_ORDER_MAKES_RETAIL P" foreign key (PartnerID)
      references "Retail Partner" (PartnerID)
go

alter table Orderitem
   add constraint FK_ORDERITE_CONTAINS_ORDER foreign key (Ord_OrderID)
      references "Order" (OrderID)
go

alter table Orderitem
   add constraint "FK_ORDERITE_IS REQUES_FORMAT" foreign key (For_FormatID)
      references Format (FormatID)
go



INSERT INTO Author (AuthorID, AuthorName, Biography) VALUES
('A00001', 'Sara Nour',   'Egyptian novelist known for historical fiction.'),
('A00002', 'Ahmed Kamal', 'Award-winning sci-fi writer.'),
('A00003', 'Lina Hassan', 'Co-author of several romance novels.'),
('A00004', 'Omar Farid',  'Debut author in mystery genre.'),
('A00005', 'Dina Samir',  'Children book specialist.')

INSERT INTO "Literary Work" (ISBN, Title, TargetAge, Genre) VALUES
('978-1001  ', 'Desert Echoes',     35, 'Historical Fiction'),
('978-1002  ', 'Beyond the Stars',  18, 'Sci-Fi'),
('978-1003  ', 'Whispers of Love',  25, 'Romance'),
('978-1004  ', 'The Silent Clue',   30, 'Mystery'),
('978-1005  ', 'Little Sky Dreams',  8, 'Children')

INSERT INTO Authorship (Lit_ISBN, Aut_AuthorID, ISBN, AuthorID, Royalty_Percentage) VALUES
('978-1001  ', 'A00001', '978-1001  ', 'A00001', 15.0),
('978-1002  ', 'A00002', '978-1002  ', 'A00002', 12.0),
('978-1003  ', 'A00003', '978-1003  ', 'A00003', 10.0),
('978-1003  ', 'A00001', '978-1003  ', 'A00001', 10.0),
('978-1003  ', 'A00002', '978-1003  ', 'A00002', 10.0),
('978-1004  ', 'A00004', '978-1004  ', 'A00004', 8.0),
('978-1005  ', 'A00005', '978-1005  ', 'A00005', 11.0)

INSERT INTO Format (FormatID, ISBN, FormatType, Cost, RetailPrice) VALUES
('1', '978-1001  ', 'Hardcover', 5.0,  25.0),
('2', '978-1001  ', 'Ebook',     1.0,  10.0),
('3', '978-1002  ', 'Hardcover', 5.0,  30.0),
('4', '978-1002  ', 'Audiobook', 3.0,  20.0),
('5', '978-1003  ', 'Hardcover', 5.0,  22.0),
('6', '978-1003  ', 'Ebook',     1.0,   9.0),
('7', '978-1004  ', 'Hardcover', 5.0,  28.0),
('8', '978-1004  ', 'Ebook',     1.0,  12.0),
('9', '978-1005  ', 'Hardcover', 4.0,  15.0),
('A', '978-1005  ', 'Audiobook', 2.0,   8.0)

INSERT INTO "Retail Partner" (PartnerID, PartnerName, PartnerType) VALUES
('P00001', 'Diwan Bookstore',  'Bookstore'),
('P00002', 'Amazon Egypt',     'Online'),
('P00003', 'Virgin Megastore', 'Bookstore'),
('P00004', 'Jamalon',          'Online'),
('P00005', 'Book Depository',  'Online')

INSERT INTO "Order" (OrderID, PartnerID, OrderDate) VALUES
('O00001', 'P00001', DATEADD(DAY, -5,  GETDATE())),
('O00002', 'P00002', DATEADD(DAY, -10, GETDATE())),
('O00003', 'P00003', DATEADD(DAY, -15, GETDATE())),
('O00004', 'P00004', DATEADD(DAY, -20, GETDATE())),
('O00005', 'P00001', DATEADD(DAY, -25, GETDATE()))

INSERT INTO Orderitem (Ord_OrderID, For_FormatID, OrderID, FormatID, Quantity) VALUES
('O00001', '1', 'O00001', '1', 20),   -- Desert Echoes Hardcover     (Historical Fiction)
('O00001', '3', 'O00001', '3', 50),   -- Beyond the Stars Hardcover  (Sci-Fi)
('O00002', '4', 'O00002', '4', 60),   -- Beyond the Stars Audiobook  (Sci-Fi)
('O00002', '6', 'O00002', '6', 15),   -- Whispers of Love Ebook      (Romance)
('O00003', '7', 'O00003', '7', 10),   -- The Silent Clue Hardcover   (Mystery)
('O00003', '2', 'O00003', '2', 10),   -- Desert Echoes Ebook         (Historical Fiction)
('O00004', '3', 'O00004', '3', 40),   -- Beyond the Stars Hardcover  (Sci-Fi)
('O00004', '5', 'O00004', '5', 12),   -- Whispers of Love Hardcover  (Romance)
('O00005', '8', 'O00005', '8', 8)     -- The Silent Clue Ebook       (Mystery)

-- INQUIRY 1
-- Which genre had the most copies sold?
SELECT TOP 1 lw.Genre, SUM(oi.Quantity) AS TotalCopiesSold
FROM "Literary Work" lw, Format f, Orderitem oi
WHERE lw.ISBN = f.ISBN
AND f.FormatID = oi.For_FormatID
GROUP BY lw.Genre
ORDER BY TotalCopiesSold DESC

-- INQUIRY 2
-- Which book had no orders in the last 30 days?
SELECT lw.Title
FROM "Literary Work" lw
WHERE lw.ISBN NOT IN (
    SELECT f.ISBN
    FROM Format f, Orderitem oi, "Order" o
    WHERE f.FormatID = oi.For_FormatID
    AND oi.Ord_OrderID = o.OrderID
    AND o.OrderDate >= DATEADD(DAY, -30, GETDATE())
)

-- INQUIRY 3
-- Which author made the highest sales revenue?
SELECT TOP 1 a.AuthorName, SUM(oi.Quantity * f.RetailPrice) AS TotalRevenue
FROM Author a, Authorship auth, Format f, Orderitem oi
WHERE a.AuthorID = auth.Aut_AuthorID
AND auth.Lit_ISBN = f.ISBN
AND f.FormatID = oi.For_FormatID
GROUP BY a.AuthorName
ORDER BY TotalRevenue DESC

-- INQUIRY 4
-- Which retail partners placed no orders in the last 30 days?
SELECT PartnerName
FROM "Retail Partner"
WHERE PartnerID NOT IN (
    SELECT PartnerID
    FROM "Order"
    WHERE OrderDate >= DATEADD(DAY, -30, GETDATE())
)

-- INQUIRY 5
-- What formats were sold for each book?
SELECT lw.Title, f.FormatType, SUM(oi.Quantity) AS UnitsSold
FROM "Literary Work" lw, Format f, Orderitem oi
WHERE lw.ISBN = f.ISBN
AND f.FormatID = oi.For_FormatID
GROUP BY lw.Title, f.FormatType
ORDER BY lw.Title

-- INQUIRY 6
-- How many books has each author written?
SELECT a.AuthorName, COUNT(auth.Lit_ISBN) AS TotalBooks
FROM Author a, Authorship auth
WHERE a.AuthorID = auth.Aut_AuthorID
GROUP BY a.AuthorName
ORDER BY TotalBooks DESC
